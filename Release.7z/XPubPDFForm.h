#ifdef XPUBPDFFORM_EXPORTS
#define XPUBPDFFORM_API __declspec(dllexport)
#else
#define XPUBPDFFORM_API __declspec(dllimport)
#endif

#include <string>

// This class is exported from the XPubPDFForm.dll
class XPUBPDFFORM_API XPubPDFForm {
public:
	XPubPDFForm();
	~XPubPDFForm();
	
	int LoadFromFile(const std::string& FileName);
	int SaveToFile(const std::string& FileName);

// Formfield

	//	0 Cross, 1 Check (Tick), 2 Dot (Radio)
	//	3 XP Check, 4 XP Radio, 5 Diamond, 6 Square, 7 Start
	int GetFormFieldCheckStyle(int Index);
	
	// 0 Unknown, 1 Text, 2 Pushbutton, 3 Checkbox
	// 4 Radiobutton, 5 Choice, 6 Signature, 7 Parent
	int GetFormFieldType(int Index);
	
	int GetFormFieldBackgroundColorType(int Index);
	int SetFormFieldBackgroundColor(int Index, double c, double m, double y, double k);
	int SetFormFieldBorderColor(int Index, double c, double m, double y, double k);

	int SetFormFieldColor(int Index, double Red, double Green, double Blue);
    int SetFormFieldCheckboxColor(int Index, double Red, double Green, double Blue);

	int UpdateAndFlattenFormFields();
	int UpdateAndFlattenFormFieldsEx();
	int UpdateAppearanceStreams();
	int SetNeedAppearances(int value);

	int FindFormFieldByTitle(const std::string& formfield);
	char* GetFormFieldValueByTitle(const std::string& formfield);
	int GetFormFieldKidCount(const int Index);
	int SetFormFieldValueByTitle(const std::string& formfield, const std::string& value);
	int SetFormFieldValueByIndex(const int Index, const std::string& value);
	char* GetFormFieldTitle(const int Index);
	int GetFormFieldCount();
	int GetPageCount();

// Merging
	int SelectedDocument();
	int SelectDocument(int DocumentID);
	int MergeDocument(int DocumentID);

protected:
	int InstanceID; 

};

